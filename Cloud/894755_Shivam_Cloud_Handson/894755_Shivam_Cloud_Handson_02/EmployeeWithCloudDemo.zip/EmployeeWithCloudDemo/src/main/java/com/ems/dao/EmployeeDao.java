package com.ems.dao;

import java.util.List;

import com.ems.entity.Employee;

public interface EmployeeDao {

	public List<Employee> getAllEmployees();
}
